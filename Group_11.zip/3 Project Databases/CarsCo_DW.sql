/* Script for the staging database */

USE [master]
GO

/* Remover SA em caso de j� existir */
DROP DATABASE IF EXISTS [Cars_Co_DW];
GO
/* Criar SA */
CREATE DATABASE [Cars_Co_DW]
GO

/* Criar tabelas para a SA */
/* create Stg_Dim_Client staging table */
USE [Cars_Co_DW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE DW_Dim_Cliente (
    SK_cliente int NOT NULL, --	id_cliente_BK int NOT NULL,
    tipo_cliente varchar(50) NULL,
    nome_cliente varchar(56) NULL,
    nome_provincia_cliente varchar(50) NULL,
    nome_cidade_cliente varchar(50) NULL,
    CONSTRAINT DW_Dim_cliente_pk PRIMARY KEY (SK_cliente)
);

/* create Stg_Dim_Data staging table */
CREATE TABLE DW_Dim_Data (
    SK_data int NOT NULL,
    ano_data int  NOT NULL,
    mes_data int  NOT NULL,
    mes_txt nvarchar(50)  NOT NULL,
	dia_semana_txt nvarchar(50)  NOT NULL,
    data date  NOT NULL,
    CONSTRAINT DW_Dim_Data_pk PRIMARY KEY (SK_data ASC)
);

/* create Stg_Dim_Fornecedor staging table */
CREATE TABLE DW_Dim_Fornecedor (
    SK_fornecedor int NOT NULL, --    id_fornecedor_BK int NOT NULL,
	nome_fornecedor varchar(25) NULL,
    pais_fornecedor varchar(25) NULL,
    cidade_fornecedor varchar(25) NULL,
	Fornecedor_SCD_Data_Inicio datetime NULL,
	Fornecedor_SCD_Data_Fim datetime NULL,
    CONSTRAINT DW_Dim_Fornecedor_pk PRIMARY KEY (SK_fornecedor ASC)
);

/* create Stg_Dim_Produto staging table */
CREATE TABLE DW_Dim_Produto (
    SK_produto int NOT NULL, --    id_produto_BK int NOT NULL,
	nome_modelo_produto varchar(50) NULL,
    nome_versao_produto varchar(50) NULL,
    nome_segmento_produto varchar(50) NULL,
    nome_marca_produto varchar(50) NULL, --    motorizacao_produto varchar(50) NULL, tracao_produto varchar(15) NULL, status_produto varchar(5) NULL,
	Produto_SCD_Data_Inicio datetime NULL,
	Produto_SCD_Data_Fim datetime NULL,
    CONSTRAINT DW_Dim_Produto_pk PRIMARY KEY (SK_produto ASC)
);

/* create Stg_Dim_Stand staging table */
CREATE TABLE DW_Dim_Stand (
    SK_stand int NOT NULL, -- id_stand_BK int NOT NULL,
	nome_stand varchar(128) NULL,
    nome_provincia_stand varchar(128) NULL,
    nome_cidade_stand varchar(128) NULL,
    CONSTRAINT DW_Dim_Stand_pk PRIMARY KEY (SK_stand ASC)
);

/* create Stg_Fact_Compra staging table */
CREATE TABLE DW_Fact_Compra (
    FK_produto int  NOT NULL,
    FK_data int  NOT NULL,
    FK_fornecedor int  NOT NULL,
    preco_base_EUR [numeric](18, 2) NULL,
    preco_base_AOA [numeric](18, 2)  NULL,
    taxas_EUR [numeric](18, 2)  NULL,
    taxas_AOA [numeric](18, 2)  NULL,
    custos_EUR [numeric](18, 2)  NULL,
    custos_AOA [numeric](18, 2)  NULL,	
    preco_total_compra_EUR [numeric](18, 2) NULL,
    preco_total_compra_AOA [numeric](18, 2)  NULL,
    CONSTRAINT DW_Fact_Compra_pk PRIMARY KEY (FK_produto ASC,FK_data ASC,FK_fornecedor ASC)
);

/* create Stg_Fact_Venda staging table */
CREATE TABLE DW_Fact_Venda (
    FK_produto int  NOT NULL,
    FK_stand int  NOT NULL,
    FK_cliente int  NOT NULL,
    FK_data int  NOT NULL,
    valor_venda_EUR [numeric](18, 2) NULL,
    valor_venda_AOA [numeric](18, 2)  NULL,
    CONSTRAINT DW_Fact_Venda_pk PRIMARY KEY (FK_produto ASC,FK_stand ASC,FK_cliente ASC,FK_data ASC)
);

/* foreign keys */
/* Reference: Stg_Fact_Compra_Stg_Dim_Data */
ALTER TABLE DW_Fact_Compra ADD CONSTRAINT DW_Fact_Compra_DW_Dim_Data
    FOREIGN KEY (FK_data)
    REFERENCES DW_Dim_Data (SK_data)
GO

/* Reference: Stg_Fact_Compra_Stg_Dim_Fornecedor */
ALTER TABLE DW_Fact_Compra ADD CONSTRAINT DW_Fact_Compra_DW_Dim_Fornecedor 
    FOREIGN KEY (FK_fornecedor)
    REFERENCES DW_Dim_Fornecedor  (SK_fornecedor)  
 GO

/* Reference: Stg_Fact_Compra_Stg_Dim_Produto */
ALTER TABLE DW_Fact_Compra ADD CONSTRAINT DW_Fact_Compra_DW_Dim_Produto
    FOREIGN KEY (FK_produto)
    REFERENCES DW_Dim_Produto (SK_produto)  
GO

/* Reference: Stg_Fact_Venda_Stg_Dim_Cliente */
ALTER TABLE DW_Fact_Venda ADD CONSTRAINT DW_Fact_Venda_DW_Dim_Cliente
    FOREIGN KEY (FK_cliente)
    REFERENCES DW_Dim_Cliente (SK_cliente)  
GO

/* Reference: Stg_Fact_Venda_Stg_Dim_Data */
ALTER TABLE DW_Fact_Venda ADD CONSTRAINT DW_Fact_Venda_DW_Dim_Data
    FOREIGN KEY (FK_data)
    REFERENCES DW_Dim_Data (SK_data)  
GO

/* Reference: Stg_Fact_Venda_Stg_Dim_Produto */
ALTER TABLE DW_Fact_Venda ADD CONSTRAINT DW_Fact_Venda_DW_Dim_Produto
    FOREIGN KEY (FK_produto)
    REFERENCES DW_Dim_Produto (SK_produto)  
GO

/* Reference: Stg_Fact_Venda_Stg_Dim_Stand */
ALTER TABLE DW_Fact_Venda ADD CONSTRAINT DW_Fact_Venda_DW_Dim_Stand
    FOREIGN KEY (FK_stand)
    REFERENCES DW_Dim_Stand (SK_stand)  
GO



/** Fim */
